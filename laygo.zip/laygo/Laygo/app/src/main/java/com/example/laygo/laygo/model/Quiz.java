package com.example.laygo.laygo.model;

public class Quiz {

}
