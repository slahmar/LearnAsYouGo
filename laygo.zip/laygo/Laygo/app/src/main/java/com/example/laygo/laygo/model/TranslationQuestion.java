package com.example.laygo.laygo.model;

/**
 * This type of question will asks for the translation of the brick
 */
public class TranslationQuestion extends Question {
}
